"""Smart Application Processing backend."""
