# Smart Application Processing

Smart Application Processing reads uploaded application documents, classifies their actual contents, extracts fields with confidence, compares them with the application form and other files, and explains the next correction or review step.

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
corepack enable
pnpm --dir frontend install
pnpm --dir frontend build
uvicorn backend.app.main:app --host 0.0.0.0 --port 3000 --reload
```

Open `http://localhost:3000`. The app uses SQLite at `data/smartapply.db` by default. Set `DATABASE_URL` to the managed DSN for the project database when available.

## Document analysis configuration

PDF text extraction uses `pypdf`. Image OCR uses the `tesseract` executable when installed. If `MANUS_API_URL` and `MANUS_API_KEY` are available, image scans can also be sent to the server-only OpenAI-compatible vision endpoint. `OPENAI_API_KEY` is supported as an alternative for local development. No provider key is embedded in the frontend bundle.

`MAX_UPLOAD_MB` defaults to 10. Supported input types are PDF, JPG, JPEG, and PNG. Uploaded files are not modified by the system. In local development, validated bytes are kept under `data/uploads`; production should use the configured durable storage adapter.

## Test

```bash
pytest -q backend/tests
pnpm --dir frontend typecheck
pnpm --dir frontend build
```

The test set covers the exact no-upload rejection message, missing required slots, empty files, and wrong-name cross-check behavior. Add fixture documents under `test-fixtures/` for provider/OCR integration tests: a correct document, wrong-name document, wrong document type, and blank file.

## Routes

- `/` — applicant form and workspace creation
- `/application/:id` — upload, health, timeline, and evidence review
- `/results/:id` — decision, issue explanations, comparison, and resubmission entry
- `/admin` — application queue and review desk
- `/health` — unauthenticated runtime health endpoint

## Known limitations and AI-assisted parts

OCR quality depends on scan clarity and the installed OCR runtime. A document that cannot be read is routed to manual review rather than guessed. Freshness policy is surfaced when issue dates are readable; a deployment can add jurisdiction-specific expiry rules. The included admin route is a review surface, not a complete identity/role system; production rollout should add role enforcement before exposing it publicly.

AI assistance is limited to vision extraction for image scans when a server-side provider is configured. PDF text extraction, field parsing, slot mismatch logic, cross-check rules, confidence thresholds, issue messages, and final status mapping are implemented as application code. The app is analysis assistance only and does not replace an official human or institutional review.
